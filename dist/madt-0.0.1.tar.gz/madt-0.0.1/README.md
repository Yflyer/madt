# MADT
## Install by conda




## Brief tutorial

```
madt main
```

## Work together with amplicon analysis platform
*Requirement*
**Notice**

[QIIME2](https://qiime2.org/)